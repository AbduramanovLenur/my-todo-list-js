import todo from './modules/todo';

document.addEventListener('DOMContentLoaded', (e) => {
    todo();
});